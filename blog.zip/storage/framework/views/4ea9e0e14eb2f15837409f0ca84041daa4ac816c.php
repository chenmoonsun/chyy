<!--如果在页面其他位置引入过jquery，此处引用可以删除-->
<script src="<?php echo e(asset('vendor/markdown/js/jquery.min.js')); ?>"></script>

<link rel="stylesheet" href="<?php echo e(asset('vendor/markdown/css/editormd.min.css')); ?>" />
<script src="<?php echo e(asset('vendor/markdown/js/editormd.min.js')); ?>"></script>
<script type="text/javascript">
    $(function() {
        <?php $__currentLoopData = $editors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        editormd("<?php echo e($editor); ?>", {
            width: "95%",
            height: 640,
            markdown : "",
            path : "<?php echo e(asset('vendor/markdown/lib')); ?>/",
            toolbarIcons : function() {
                return ["undo", "redo", "|", "bold", "del", "italic", "quote", "ucwords", "uppercase", "lowercase", "|", "h1", "h2", "h3", "h4", "h5", "h6", "|", "list-ul", "list-ol", "hr", "|", "link", "reference-link", "image", "code", "preformatted-text", "code-block", "table", "datetime", "emoji", "html-entities", "pagebreak", "||", "goto-line", "watch", "clear", "preview", "fullscreen"]
            },
            imageUpload : true,
            imageFormats : ["jpg", "jpeg", "gif", "png", "bmp", "webp"],
            imageUploadURL : "<?php echo e(url('markdown/upload')); ?>",
        });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    });

</script>